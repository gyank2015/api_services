from django.apps import AppConfig


class AvengersDjangoModelsAppConfig(AppConfig):
    name = 'avengers_django_models_app'
